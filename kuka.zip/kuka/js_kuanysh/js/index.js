  var name = window.prompt('Enter your name: ');
  alert("Welcome back, " + name);

function Boxing() {
  alert('I love boxing!');
}

function square() {
  var Square = document.getElementById('class1').value;
    alert("Square of number " + document.getElementById('class1').value + " is " + Square * Square);
}
function gun() {
  var audio = new Audio('https://www.fesliyanstudios.com/play-mp3/7125');
  audio.play();
}
var random = Math.floor((Math.random() * 10) + 1);
var tOut = document.getElementById('i');
tOut.innerHTML = random;

function foo() {
  var number;
  var output;
    number = document.getElementById('class2').value;
    output = document.getElementById('output');
    if(number == random) output.innerHTML = "Winner!"
    else if (number > random) output.innerHTML = "Loser, you need to enter much less number!";
    else output.innerHTML = "Loser, you need to enter bigger number!";
}
